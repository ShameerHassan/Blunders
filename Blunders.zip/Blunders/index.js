

const path=require('path');


// built-in middleware

var express = require('express'); 
 var app = express();

app.set('view engine', 'ejs');

var bodyParser = require('body-parser');
  app.use(bodyParser.urlencoded({ extended: true }));

 var Person=require('./Person.js');

const staticpath=path.join(__dirname,'/public')
app.use(express.static(staticpath));




app.get("/login",(req,res)=>{

    res.sendFile(__dirname+'/public/login.html');

});
app.use('/logsub', (req, res) => {

var newPerson = new Person ({ // defined in Person.js
Email:req.body.name,
Institution:req.body.age,
Address:req.body.address,
});

newPerson.save( ) ;

res.render("created.ejs");

});


app.get('/*' , (req, res) => {
  res.sendFile(__dirname +'/public/404.html');
});

// this is at the bottom
app.listen(3000,()=>{
    console.log("Running On server");
});