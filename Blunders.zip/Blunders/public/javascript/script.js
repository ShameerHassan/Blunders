    
    
    
    var textAnimated = document.querySelector(".textAnimated")

            var text = ""

            var textArr = [
                "Quality Courses ,trusted by 500,000 students all over the world",
                "Largest website for free education in the world",
                "Best Instructors of Blunders are for you",
                
            ]

            var currentTextIndex = -1

            var letterIndex = -1

            function addLetter() {
                // increment letterIndex to get to the next letter
                letterIndex++
                //
                if (letterIndex < text.length) {
                    //ADD A DELAY
                    setTimeout(function () {
                        // add letter
                        textAnimated.textContent += text[letterIndex]
                        // call itself 
                        addLetter()
                    }, 100)
                } else {
                    // call removeLetter after a delay 
                    setTimeout(function () {
                        removeLetter()
                    }, 2000)
                }
            }

            function removeLetter() {
                // decrement letterIndex to get to the next letter
                letterIndex--
                //
                if (letterIndex >= 0) {
                    //ADD A DELAY
                    setTimeout(function () {
                        // remove letter
                        textAnimated.textContent = text.slice(0, letterIndex)
                        // call itself 
                        removeLetter()
                    }, 100)
                } else {
                    // no more letters to remove
                    // doesn't call addLetter anymore
                    // call updateText instead
                    updateText()
                }
            }

            function updateText() {
                //increment currentTextIndex to switch to the next sentence
                currentTextIndex++

                //go to the first string index when currentTextIndex has reached the last one
                if (currentTextIndex === textArr.length) {
                    currentTextIndex = 0
                }
                //update text 
                text = textArr[currentTextIndex]
                //call addLetter and get the animation going
                addLetter()
            }

            //the initial call to start everything
            updateText()


    
    
    
    
    
    var imagee = new Array();
            imagee[0] = 'images/comments.png';
            imagee[1] = 'images/com22.png';
           imagee[2] ="images/com33.png";
            imagee[3]="images/com44.png";
           var a=0;

        function  forward() {
            if (a < imagee.length-1 ) {
                a ++;
                document.getElementById("image").src = imagee[a];
            }
            
            
        }
         function backward() {
               if (a > 0) {
                 a --;
                  document.getElementById('image').src = imagee[a];
             }
            
         }
//jquery
$(document).ready(function(){

    $("#im1").hide();
  $("body").mouseover(function(){
   $("#im1").slideDown(500);
  });
  $("#para2").hide();
 $("#div3").mouseover(function(){
   $("#para2").fadeIn(500);
  });



  $("#div4").mouseenter(function(){
  
  $("#im2").animate({opacity:'1'}, "slow");
   $("#im3").animate({opacity:'1'}, "slow");
    $("#im4").animate({opacity:'1'}, "slow");
 

}); 



$("#dark").click(function(){
  
$("#bd").css("background-color", "#8E8E8E");
   

}); 

// $("#im5").hide();
//  $("#div6").mouseenter(function(){
//    $("#im5").fadeIn(500);
//   });

  $("#img7").hide();

   $("#div9").mouseover(function(){
   $("#img7").show(500);
  });


});

 $(".change").on("click", function () {
                    if ($("body").hasClass("dark")) {
                        $("body").removeClass("dark");


                    } else {
                        $("body").addClass("dark");

                    }
                }); 

