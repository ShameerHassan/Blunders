const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/registerspeople" , {

useNewUrlParser:true,
useUnifiedTopology:true,
useCreateIndex:true
}).then(()=> { 
console.log(    `connection successful......!`);
}).catch((e)=>{
    // console.log( e);
    console.log(  `no connection`);
})

var Schema = mongoose.Schema;
var personSchema = new Schema( {
Email: {type: String, required: true,unique:true},
Institution: String,
Address:String,
} );

module.exports = mongoose.model('Person', personSchema);
